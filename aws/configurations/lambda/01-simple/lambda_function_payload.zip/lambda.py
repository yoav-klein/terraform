

def handler(context, event):
    return {'statusCode': 200, 'message': "Got you!"}
